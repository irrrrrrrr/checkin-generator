# workers/template_worker.py
import sys
from modules.split import copy, run

def main():
    copy()
    run('./temp/template.xlsx')

if __name__ == "__main__":
    main()