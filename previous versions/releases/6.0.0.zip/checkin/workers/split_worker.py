# workers/split_worker.py
import sys
from modules.split import process_excel_file
from pathlib import Path

def main():
    desktop_path = Path(sys.argv[1])
    process_excel_file(desktop_path)

if __name__ == "__main__":
    main()